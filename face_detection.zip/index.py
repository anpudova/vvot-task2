import boto3
import json
import cv2
import numpy as np
import os

s3_client = boto3.client(
    "s3",
    endpoint_url="https://storage.yandexcloud.net",
    aws_access_key_id=os.getenv("YANDEX_ACCESS_KEY"),
    aws_secret_access_key=os.getenv("YANDEX_SECRET_KEY"),
)

sqs_client = boto3.client(
    "sqs",
    endpoint_url="https://message-queue.api.cloud.yandex.net",
    aws_access_key_id=os.getenv("YANDEX_ACCESS_KEY"),
    aws_secret_access_key=os.getenv("YANDEX_SECRET_KEY"),
    region_name="ru-central1",
)

def detect_faces(image_bytes):
    np_image = np.frombuffer(image_bytes, np.uint8)
    image = cv2.imdecode(np_image, cv2.IMREAD_COLOR)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    
    return [(int(x), int(y), int(w), int(h)) for (x, y, w, h) in faces]

def send_message_to_queue(queue_url, message_body):
    try:
        response = sqs_client.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(message_body),
        )
        print(f"Message sent! ID: {response['MessageId']}")
    except Exception as e:
        print(f"Error sending message: {e}")

def handler(event, context):
    queue_url = os.getenv("URL_QUEUE")

    for message in event['messages']:
        bucket_name = message['details']['bucket_id']
        object_key = message['details']['object_id']

        event_type = message['event_metadata']['event_type']
        if event_type != "yandex.cloud.events.storage.ObjectCreate":
            print(f"Skipping event type: {event_type}")
            continue

        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        image_bytes = response['Body'].read()

        faces = detect_faces(image_bytes)

        for face_id, (x, y, w, h) in enumerate(faces):
            task = {
                "original_photo_key": object_key,
                "face_rectangle": {"x": x, "y": y, "w": w, "h": h},
            }
            send_message_to_queue(queue_url, task)

    return {"statusCode": 200}